# The Great Discovery
### Discovery Pressure Core — v5.0

---

> *A sealed system, left alone, settles into the only configuration that doesn't contradict itself.*
> *This engine watches that happen.*

---

## The Problem

The sum of human knowledge is too large to hold, too interconnected to index, and too alive to pin down with a theorem. Every attempt to map it completely has either frozen it in place or drowned in its own complexity.

Mendeleev didn't map every atom. He found the table's shape — and the shape told him what had to exist.

**This engine is built on that method, applied to knowledge structure.**

---

## What It Does

The Great Discovery is a constraint-accumulation engine built around a growing knowledge graph. It does not store knowledge. It does not retrieve answers. It maps the **structural shape that knowledge implies** — by accumulating forbidden configurations and watching what the remaining topology demands.

Each epoch the engine:
1. **Grows** the graph — new nodes, new edges, biased toward structurally significant regions
2. **Measures** structural pressure — compression ratio and Shannon entropy of motif distribution
3. **Detects** forbidden motifs — structural patterns whose appearance destabilizes the topology
4. **Accumulates** the edges of the table — the constraints that give holes their shape

The feedback loop is closed. Each pass leaves the engine more constrained than before — which means more precise.

---

## Core Concepts

**Hole** — A load-bearing absence. A configuration the surrounding topology requires for self-consistency that has not yet been filled. Not missing data. Not an error. A structural debt. Like germanium before Mendeleev named it — the surrounding constraints made its existence not probable but mandatory.

**Forbidden Motif** — A structural pattern that, when it appears, causes compression to spike. The topology becomes suddenly less diverse — a sign of strain, not convergence. Forbidden motifs are the edges of the table. They accumulate over time, progressively narrowing what configurations are permitted, giving holes their shape.

**Compression Ratio** — Unique motif signatures divided by total motif observations. High compression (ratio near 0) means the graph is repeating itself — converging. Low compression (near 1) means it is still exploring. A sudden spike in compression is the primary governance signal.

**Settling** — The process by which a structure finds its natural position in the topology because the surrounding constraints made every other position forbidden. Nothing is forced. If something won't settle, that is signal too.

---

## Architecture

```
GROW → MEASURE → GOVERN → UPDATE → GROW → ...
       ↑                      |
       └──── forbidden ────────┘
             accumulates
             holes sharpen
             map becomes opinionated
```

| Component | File | Role |
|---|---|---|
| Core Engine | `core_engine.py` | SQLite persistence — nodes, edges, motifs, forbidden |
| Explorer | `explorer.py` | Graph growth with degree-biased node placement and hole allocation |
| Pressure Engine | `pressure_engine.py` | Motif sampling, canonical signatures, compression + entropy |
| Governance | `governance.py` | Compression spike detection, forbidden motif recording |
| Driver | `driver.py` | Epoch orchestration and reporting |
| Structural Models | `core_structural/` | Constraint, graph, incentive, and system models |

Full architecture documentation: [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md)

---

## Running It

**Requirements**
```bash
pip install -r requirements.txt
```

**Single run — 50 epochs**
```bash
python driver.py
```

**Stress test — 100 epochs**
```bash
python stress_test.py
```

**Governance demo**
```bash
python driver.py --demo governance
```

**Live visual dashboard**

Open `dashboard.html` in any browser. No server required. Watch the graph grow, compression move, and forbidden motifs fire in real time.

**Output**
```
 Epoch   Compression     Entropy       Delta  Event
-----------------------------------------------------------------
     0        1.0000      0.0000      0.0000
     1        0.8333      0.6931     -0.1667
    ...
    23        0.4412      1.8750     -0.0201
    24        0.6100      1.4230      0.1688  FORBIDDEN #1 (spike=0.1688)
```

Watch the Delta column. Sustained negative delta means the table is filling. Spikes are edges of the table being found. Flatline near zero is local equilibrium.

---

## Current State — Phase 0

The engine is structurally complete and running. The pressure dynamics are real. Compression spikes are genuine signal. The feedback loop is closed.

What is present:
- ✅ Closed-loop constraint accumulation
- ✅ Isomorphism-invariant motif signatures (permutation minimization)
- ✅ Degree-biased exploration with pressure-weighted hole allocation
- ✅ Shannon entropy measurement
- ✅ Forbidden motif detection and persistence
- ✅ Live visual dashboard

What is not yet present — intentionally:
- ❌ Semantic weight (nodes are anonymous — pure topology)
- ❌ Energy minimization in hole allocation (currently transitive closure)
- ❌ Exploration bias toward highest-pressure holes
- ❌ Named holes surfaced in language

This is not a disclaimer. It is the current position on the roadmap. The structural dynamics must be trustworthy before meaning is introduced. A pressure engine that misbehaves on pure topology will misbehave worse when concepts are loaded in.

Full roadmap: [`docs/ROADMAP.md`](docs/ROADMAP.md)

---

## Mathematical Grounding

The engine sits at the intersection of four established research domains without fully belonging to any:

- **Constraint Satisfaction** — forbidden motif accumulation is analogous to clause learning in SAT solvers, but operating on graph topology rather than boolean variables
- **Topological Data Analysis** — compression and entropy measure the persistent structural features of the evolving graph
- **Emergent System Simulation** — pressure dynamics produce macro-level behavior (settling, spiking, equilibrium) from local rules
- **Information-Theoretic Search** — the engine maximizes structural information gain, naturally biasing toward underexplored regions

The closest existing framework is probably **constraint-driven graph rewriting with emergent forbidden pattern accumulation** — but this combination does not appear in the literature in this specific form.

---

## The Name

*The Great Discovery* — The Movement, from *Way of the World.* Alan Watts speaks at the opening of the track.

The discovery is not a fact found at the end of a search. It is the searching itself, happening recursively, without end.

---

## Roadmap Summary

| Phase | Status | Goal |
|---|---|---|
| 0 — Structural Foundation | ✅ Complete | Running engine, closed-loop pressure dynamics |
| 1 — Structural Integrity | 🔧 In progress | Isomorphism invariance, scalable sampling, exploration bias toward holes |
| 2 — Abstraction Layer | Planned | Typed nodes and edges, semantic pressure, energy minimization |
| 3 — Named Holes | Planned | Engine surfaces holes as questions in language |
| 4 — Recursive Sharpening | Planned | Engine maps its own discovery process |

---

## License

MIT — use it, break it, build on it, tell us what you find.

---

*The map sharpens the mapmaker. The mapmaker sharpens the map.*
